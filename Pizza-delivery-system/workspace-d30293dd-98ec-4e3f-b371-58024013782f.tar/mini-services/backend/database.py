from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base,sessionmaker


engine=create_engine('sqlite:////home/z/my-project/mini-services/backend/pizza.db',
    echo=True,
    connect_args={"check_same_thread": False}
)

Base=declarative_base()

Session=sessionmaker()